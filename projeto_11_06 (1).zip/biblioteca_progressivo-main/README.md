# 📚 Projeto Biblioteca

> 🧑‍💻 Este projeto está sendo desenvolvido com os alunos da turma do **3º ano do Ensino Médio do Curso Técnico Integrado**.

---

## 🚀 Como Rodar o Projeto na Sua Máquina

Siga o passo a passo abaixo para configurar e executar o projeto localmente.

### 1️⃣ Baixar e Extrair

Baixe o arquivo `.zip` do projeto e faça a descompactação dele em uma pasta de sua preferência no seu computador.

---

### 2️⃣ Limpar e Restaurar Dependências

Abra a pasta do projeto no **Visual Studio Code**, abra um novo terminal e execute os comandos abaixo para limpar o cache e restaurar os pacotes NuGet:

```powershell
# Limpa os artefatos de builds anteriores
dotnet clean

# Restaura as dependências/pacotes do projeto
dotnet restore
````

---

### 3️⃣ Configurar o Banco de Dados (MySQL)

Precisamos ajustar a string de conexão para que o projeto converse com o seu banco de dados local.

1. Abra o arquivo `appsettings.json` (ou `appsettings.Development.json`);
2. Altere os campos `Server`, `Port`, `Uid` (usuário) e `Pwd` (senha) com as credenciais do seu **MySQL Workbench**.

---

### 4️⃣ Sincronizar as Tabelas (Migrations)

O projeto utiliza o **Entity Framework Core**. Para criar o banco de dados e as tabelas automaticamente na sua máquina, execute:

```powershell
dotnet ef database update
```

---

### 5️⃣ Compilar e Executar o Projeto

Antes de rodar, vamos compilar o projeto para garantir que não há erros de sintaxe:

```powershell
dotnet build
```

Tudo certo? Agora escolha uma das opções abaixo para executar a aplicação:

#### ▶️ Modo Normal

```powershell
dotnet run
```

#### 🔥 Modo Desenvolvimento (Recomendado)

Atualiza a aplicação automaticamente sempre que houver alterações no código.

```powershell
dotnet watch
```

---

## 🕒 Status do Projeto & Próximos Passos

### 🛑 Onde paramos? (Aula de 11/06)

Durante a última aula, iniciamos a implementação da lógica para **Editar Livros**. Criamos com sucesso o método `GET` na nossa `Controller` para buscar os dados do livro.

### 🎯 Próximos Passos

* [ ] Implementar o método `POST` na `Controller` para salvar as alterações do livro;
* [ ] Criar a `View` (tela) que conterá o formulário de edição;
* [ ] Implementar a lógica de exclusão (`Delete`) de registros para finalizar o CRUD.


