using Biblioteca.Models;
using Microsoft.EntityFrameworkCore;

namespace Biblioteca.Repositories;

public class LivroRepository : ILivroRepository
{
    readonly BibliotecaContext _context;

    public LivroRepository(BibliotecaContext context)
    {
        _context = context;
    }

    public async Task<List<Livro>> BuscarTodosLivrosAsync()
    {
        return await _context.Livros.Include(x => x.Autor).ToListAsync();
    }

    public async Task<bool> CriarLivroAsync(Livro livro, int AutorId)
    {
        livro.Autor = await _context.Autores.FirstOrDefaultAsync(x => x.Id == AutorId);
        await _context.Livros.AddAsync(livro);
        await _context.SaveChangesAsync();
        return true;
    }

    public async Task<bool> AtualizarLivroAsync(Livro Livro)
    {
        var livroBanco = await _context.Livros.Include(x => x.Autor).FirstOrDefaultAsync(x => x.Id == Livro.Id);

        if (livroBanco == null) return false;

        livroBanco.Titulo = Livro.Titulo;
        livroBanco.Genero = Livro.Genero;
        livroBanco.NumPaginas = Livro.NumPaginas;
        livroBanco.DataPublicacao = Livro.DataPublicacao;

        livroBanco.Autor = Livro.Autor;

        await _context.SaveChangesAsync();
        return true;
    }
}

public interface ILivroRepository
{
    Task<List<Livro>> BuscarTodosLivrosAsync();
    Task<bool> CriarLivroAsync(Livro livro, int AutorId);
    Task<bool> AtualizarLivroAsync(Livro Livro);
}