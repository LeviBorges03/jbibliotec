using Biblioteca.Models;
using Biblioteca.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace Biblioteca.Controllers;

public class BibliotecaController : Controller
{
    readonly ILivroRepository _livroRepository;
    readonly IAutorRepository _autorRepository;

    public BibliotecaController(ILivroRepository livroRepository, IAutorRepository autorRepository)
    {
        _livroRepository = livroRepository;
        _autorRepository = autorRepository;
    }

    public IActionResult Index()
    {
        List<Livro> l1 = new List<Livro>()
        {
            new Livro
            {
                Titulo = "Harry Potter",
                NumPaginas = 150,
                //Autor = "Fulano",
                Genero = "Ficção Científica",
                DataPublicacao = DateOnly.MaxValue   
            },
            new Livro
            {
                Titulo = "Alíce no País das Maravilhas",
                NumPaginas = 500,
                //Autor = "Fulana",
                Genero = "Fantasia",
                DataPublicacao = DateOnly.MinValue
            }
        };

        return View(l1);
    }

    public async Task<IActionResult> Livro()
    {
        // Busca os livros reais do seu repositório
        List<Livro> livros = await _livroRepository.BuscarTodosLivrosAsync();
        return View(livros);
    }


    public async Task<IActionResult> Autor()
    {
        // Busca os autores reais do seu repositório
        // (Certifique-se de que seu IAutorRepository possui esse método)
        var autores = await _autorRepository.BuscarTodosAutoresAsync();
        return View(autores);
    }

    public async Task<IActionResult> CriarLivroAsync()
    {
        ViewBag.Autores = new SelectList(
            await _autorRepository.BuscarTodosAutoresAsync(),
            "Id",
            "Nome"
        );
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> CriarLivroAsync(CriarLivroViewModel livroViewModel)
    {
        Livro livro = new()
        {
            DataPublicacao = livroViewModel.DataPublicacao,
            Genero = livroViewModel.Genero,
            NumPaginas = livroViewModel.NumPaginas,
            Titulo = livroViewModel.Titulo
        };
        await _livroRepository.CriarLivroAsync(livro, livroViewModel.AutorId);
        return RedirectToAction("Livro");
    }

    [HttpGet]
    public async Task<IActionResult> EditarLivro(int id)
    {
        var livros = await _livroRepository.BuscarTodosLivrosAsync();
        var livro = livros.FirstOrDefault(x => x.Id == id);

        if(livro == null) return NotFound();

        var viewModel = new EditarLivroViewModel
        {
            Id = livro.Id,
            Titulo = livro.Titulo,
            NumPaginas = livro.NumPaginas,
            Genero = livro.Genero,
            DataPublicacao = livro.DataPublicacao,
            AutorId = livro.Autor?.Id ?? 0
        };

        ViewBag.Autores = new SelectList(
            await _autorRepository.BuscarTodosAutoresAsync(),
            "Id",
            "Nome",
            viewModel.AutorId
        );

        return View(viewModel);
    }

    public IActionResult CriarAutor()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> CriarAutorAsync(Autor autor)
    {
        await _autorRepository.CriarAutorAsync(autor);

        return RedirectToAction("Autor");
    }
}